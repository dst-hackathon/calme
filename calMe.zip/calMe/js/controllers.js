angular.module('app.controllers', [])
  
.controller('billCtrl', function($scope) {

})
   
.controller('sharesCtrl', function($scope) {

})
   
.controller('dishesCtrl', function($scope) {

})
   
.controller('payCtrl', function($scope) {

})
 